<?php

namespace SkreenHouseFactory\v3Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SkreenHouseFactoryV3Bundle extends Bundle
{
}
